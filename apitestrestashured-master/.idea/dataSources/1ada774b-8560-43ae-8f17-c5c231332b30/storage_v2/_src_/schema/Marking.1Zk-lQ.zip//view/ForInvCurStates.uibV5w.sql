CREATE VIEW Marking.ForInvCurStates
            (
             `invoice_1C_id` String,
             `state_name` String
                )
AS
SELECT invoice_1C_id,
       argMax(state_name, state_dt) AS state_name
FROM Marking.`Invoices.States`
GROUP BY invoice_1C_id;

