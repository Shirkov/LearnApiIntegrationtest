CREATE VIEW Marking.CargoIsShipped
            (
             `cargo_1C_id` String,
             `InvoiceAcCount` UInt64,
             `CargoAcCount` UInt64
                )
AS
SELECT res.cargo_1C_id,
       sum(res.q = 1) AS InvoiceAcCount,
       sum(res.q = 2) AS CargoAcCount
FROM (
         SELECT DISTINCT cargo.`1C_id` AS cargo_1C_id,
                         res.box_ac    AS box_ac,
                         1             AS q
         FROM Marking.cargo
                  INNER JOIN Marking.Invoices ON (Invoices.invoice_1C_id = cargo.invoice_1C_id) AND
                                                 (Invoices.invoice_incongruity_bit = 0)
                  INNER JOIN
              (
                  SELECT m.box_ac,
                         m.invoice_1C_id
                  FROM Marking.`Invoices.MarkingCodes` AS m
                           FINAL
                  ) AS res ON res.invoice_1C_id = cargo.invoice_1C_id
         UNION ALL
         SELECT DISTINCT `Cargo.ActualAC`.cargo_1C_id AS cargo_1C_id,
                         box_AC                       AS box_ac,
                         2                            AS q
         FROM Marking.`Cargo.ActualAC`
         ) AS res
         LEFT JOIN Marking.`Cargo.States`
                   ON (`Cargo.States`.cargo_1C_id = res.cargo_1C_id) AND (`Cargo.States`.state_name = 'Отгружен')
WHERE `Cargo.States`.state_name = ''
GROUP BY res.cargo_1C_id,
         state_name;

