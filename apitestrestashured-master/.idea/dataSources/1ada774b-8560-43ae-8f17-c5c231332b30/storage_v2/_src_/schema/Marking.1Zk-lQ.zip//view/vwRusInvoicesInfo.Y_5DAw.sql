CREATE VIEW Marking.vwRusInvoicesInfo
            (
             `number_dt` String,
             `numberInvoice` String,
             `state_name` String,
             `item_ids` UUID,
             `GTIN` String,
             `bloc_multiplicity` UInt32,
             `box_multiplicity` UInt32,
             `box_qty` UInt32,
             `item_qty` UInt64,
             `box_AC` String,
             `bloc_AC` String,
             `marking_code` String
                )
AS
SELECT concat(argMax(number, timestamp), ' / ', toString(argMax(invoice_dt, timestamp))) AS number_dt,
       argMax(number, timestamp)                                                         AS numberInvoice,
       argMax(state_name, timestamp)                                                     AS state_name,
       toUUID(argMax(item_idd, timestamp))                                               AS item_ids,
       argMax(item_GTINd, timestamp)                                                     AS GTIN,
       argMax(bloc_multiplicityd, timestamp)                                             AS bloc_multiplicity,
       argMax(box_multiplicityd, timestamp)                                              AS box_multiplicity,
       argMax(box_qtyd, timestamp)                                                       AS box_qty,
       argMax(box_qtyd, timestamp) * argMax(box_multiplicityd, timestamp)                AS item_qty,
       concat(argMax(box_ACd, timestamp), '')                                            AS box_AC,
       argMax(bloc_ACd, timestamp)                                                       AS bloc_AC,
       concat(argMax(marking_coded, timestamp), '')                                      AS marking_code
FROM Marking.RusInvoices
    ARRAY JOIN
     details.item_id AS item_idd,
     details.item_GTIN AS item_GTINd,
     details.bloc_multiplicity AS bloc_multiplicityd,
     details.box_multiplicity AS box_multiplicityd,
     details.box_qty AS box_qtyd,
     details.item_qty AS item_qtyd,
     details.box_AC AS box_ACd,
     details.bloc_AC AS bloc_ACd,
     details.marking_code AS marking_coded
GROUP BY number,
         marking_coded,
         box_ACd,
         bloc_ACd;

