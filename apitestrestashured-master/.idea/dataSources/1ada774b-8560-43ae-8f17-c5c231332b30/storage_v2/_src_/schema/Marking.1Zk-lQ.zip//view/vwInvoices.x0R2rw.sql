CREATE VIEW Marking.vwInvoices
            (
             `Invoices.row_id` UUID,
             `Invoices.invoice_1C_id` String,
             `Invoices.invoice_number` String,
             `Invoices.invoice_creation_dt` DateTime,
             `Invoices.invoice_completion_dt` DateTime,
             `Invoices.invoice_incongruity_bit` UInt8,
             `Invoices.company_id` UUID,
             `Invoices.counterparty_id` UUID,
             `Invoices.procurement_officer_id` UUID,
             `Invoices.1C_user_id` UUID,
             `Invoices.item_id` UUID,
             `Invoices.conformity_certificate_id` UUID,
             `Invoices.CN_FEA_code_id` UUID,
             `Invoices.item_GTIN` String,
             `Invoices.box_GTIN` String,
             `Invoices.box_qty` UInt32,
             `Invoices.box_multiplicity` UInt32,
             `Invoices.bloc_GTIN` String,
             `Invoices.bloc_multiplicity` UInt16,
             `price` Nullable(Nothing),
             `price_vat` Nullable(Nothing),
             `mc` Nullable(Nothing),
             `bloc_ac` Nullable(Nothing),
             `box_ac` Nullable(Nothing),
             `box_ac_upd` Nullable(Nothing),
             `qty_upd` Nullable(Nothing),
             `error` UInt8,
             `state` LowCardinality(String),
             `state_dt` DateTime,
             `invoiceType` String
                )
AS
SELECT Invoices.row_id,
       Invoices.invoice_1C_id,
       Invoices.invoice_number,
       Invoices.invoice_creation_dt,
       Invoices.invoice_completion_dt,
       Invoices.invoice_incongruity_bit,
       Invoices.company_id,
       Invoices.counterparty_id,
       Invoices.procurement_officer_id,
       Invoices.`1C_user_id`,
       Invoices.item_id,
       Invoices.conformity_certificate_id,
       Invoices.CN_FEA_code_id,
       Invoices.item_GTIN,
       Invoices.box_GTIN,
       Invoices.box_qty,
       Invoices.box_multiplicity,
       Invoices.bloc_GTIN,
       Invoices.bloc_multiplicity,
       NULL                         AS price,
       NULL                         AS price_vat,
       NULL                         AS mc,
       NULL                         AS bloc_ac,
       NULL                         AS box_ac,
       NULL                         AS box_ac_upd,
       NULL                         AS qty_upd,
       0                            AS error,
       `Invoices.States`.state_name AS state,
       `Invoices.States`.state_dt   AS state_dt,
       'forign'                     AS invoiceType
FROM Marking.Invoices
         INNER JOIN Marking.`Invoices.States` ON `Invoices.States`.invoice_1C_id = Invoices.invoice_1C_id
         INNER JOIN
     (
         SELECT invoice_1C_id,
                max(state_dt) AS maxstate_dt
         FROM Marking.`Invoices.States`
         GROUP BY invoice_1C_id
         ) AS res ON (res.invoice_1C_id = Invoices.invoice_1C_id) AND (res.maxstate_dt = `Invoices.States`.state_dt);

