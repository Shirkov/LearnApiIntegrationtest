CREATE VIEW Marking.vwKMDataByCargoDBG
            (
             `counterpartyId` String,
             `businessNumber` String,
             `documentId` String,
             `businessDt` Nullable(DateTime),
             `skuId` String,
             `SKU` String,
             `item_GTIN` String,
             `INN` String,
             `box_ac` String,
             `block_ac` String,
             `marking_code` String,
             `bloc_multiplicity` UInt32,
             `box_multiplicity` UInt32
                )
AS
SELECT counterpartyId,
       businessNumber,
       documentId,
       businessDt,
       skuId,
       SKU,
       item_GTIN,
       INN,
       box_ac,
       block_ac,
       marking_code,
       bloc_multiplicity,
       box_multiplicity
FROM (
         SELECT Counterparties.`1C_id`                              AS counterpartyId,
                cargo.number                                        AS businessNumber,
                cargo.batch_1C_id                                   AS documentId,
                cargo.completion_dt                                 AS businessDt,
                Items.`1C_id`                                       AS skuId,
                Items.SKU                                           AS SKU,
                Invoices.item_GTIN                                  AS item_GTIN,
                Companies.INN                                       AS INN,
                `Invoices.MarkingCodes`.box_ac                      AS box_ac,
                `Invoices.MarkingCodes`.block_ac                    AS block_ac,
                substr(`Invoices.MarkingCodes`.marking_code, 1, 31) AS marking_code,
                toUInt32(`Invoices.MarkingCodes`.bloc_multiplicity) AS bloc_multiplicity,
                toUInt32(`Invoices.MarkingCodes`.box_multiplicity)  AS box_multiplicity
         FROM Marking.`Invoices.MarkingCodes`
                  FINAL
                  INNER JOIN Marking.Invoices
             FINAL
         ON `Invoices.MarkingCodes`.invoice_row_id = Invoices.row_id
             INNER JOIN Marking.cargo
             FINAL ON Invoices.invoice_1C_id = cargo.invoice_1C_id
             INNER JOIN Marking.Counterparties ON Counterparties.id = Invoices.counterparty_id
             INNER JOIN Marking.Items ON Items.id = Invoices.item_id
             INNER JOIN Marking.Companies ON Invoices.company_id = Companies.id
             INNER JOIN Marking.Const ON (Const.key = 'cache.doSendKMMoveOnBatchReceive') AND (Const.value = 'true')
         ORDER BY
             Counterparties.`1C_id` ASC,
             cargo.`1C_id` ASC,
             Items.`1C_id` ASC,
             Invoices.item_GTIN ASC,
             Companies.INN ASC,
             `Invoices.MarkingCodes`.box_ac ASC
         UNION ALL
         SELECT DISTINCT
             Counterparties.`1C_id` AS counterpartyId,
             businessNumber,
             documentId,
             businessDt,
             Items.`1C_id` AS skuId,
             Items.SKU AS SKU,
             res.item_GTIN AS item_GTIN,
             Companies.INN AS INN,
             box_ac,
             block_ac,
             marking_code,
             bloc_multiplicity,
             box_multiplicity
         FROM
             (
             SELECT
             cargo.`1C_id` AS cargo_1C_id,
             cargo.number AS businessNumber,
             cargo.batch_1C_id AS documentId,
             cargo.completion_dt AS businessDt,
             d_box_AC AS box_ac,
             d_block_ac AS block_ac,
             substr(d_marking_code, 1, 31) AS marking_code,
             d_bloc_multiplicity AS bloc_multiplicity,
             d_box_multiplicity AS box_multiplicity,
             toUUID(d_item_id) AS item_id,
             d_item_GTIN AS item_GTIN,
             argMax(r.counterparty_id, r.timestamp) AS counterparty_id,
             argMax(r.company_id, r.timestamp) AS company_id
             FROM Marking.RusInvoices AS r
             ARRAY JOIN
             `details.box_AC` AS d_box_AC,
             `details.bloc_AC` AS d_block_ac,
             `details.marking_code` AS d_marking_code,
             `details.bloc_multiplicity` AS d_bloc_multiplicity,
             `details.box_multiplicity` AS d_box_multiplicity,
             `details.item_id` AS d_item_id,
             `details.item_GTIN` AS d_item_GTIN
             INNER JOIN Marking.cargo AS c
             FINAL ON r.`1C_id` = c.invoice_1C_id
             GROUP BY
             cargo.number,
             cargo.`1C_id`,
             cargo.batch_1C_id,
             cargo.completion_dt,
             d_item_id,
             d_box_AC,
             d_block_ac,
             d_marking_code,
             d_bloc_multiplicity,
             d_box_multiplicity,
             d_item_GTIN
             ) AS res
             LEFT JOIN Marking.Counterparties
         ON Counterparties.id = res.counterparty_id
             INNER JOIN Marking.Items ON Items.id = res.item_id
             INNER JOIN Marking.Companies ON res.company_id = Companies.id
             INNER JOIN Marking.Const ON (Const.key = 'cache.doSendKMMoveOnBatchReceive') AND (Const.value = 'true')
         ORDER BY
             Counterparties.`1C_id` ASC,
             cargo_1C_id ASC,
             Items.`1C_id` ASC,
             res.item_GTIN ASC,
             Companies.INN ASC,
             box_ac ASC
         ) AS res_all
WHERE marking_code != '';

